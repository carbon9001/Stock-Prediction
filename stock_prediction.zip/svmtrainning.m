clear Xtrain Ytrain X_iter ccr ccr_final ypredict cm svmstruct trin tein cv
time_size=12;
size2=119;
%construct the training
%construct label

for s=1:ms
    for i=1:(size2-time_size-1)
        Xtrain(i,:)=Zica(s,i:i+time_size);
        Ytrain(i,1)=Zica(s,i+time_size+1);        
    end

    Ytrain(Ytrain>0)=1;
    Ytrain(Ytrain<0)=-1;
    X_iter=Zica(s,107:119);
%     cv=cvpartition(Ytrain,'Kfold',4);
%     for i=1:cv.NumTestSets
%         trin=cv.training(i);
%         tein=cv.test(i);
%         svmstruct=svmtrain(Xtrain(trin,:),Ytrain(trin,:));
%         ypredict=svmclassify(svmstruct,Xtrain(tein,:));
%         cm=confusionmat(Ytrain(tein,:),ypredict);
%         ccr(s,i)=sum(diag(cm))/sum(sum(cm,1),2);
%     end
%     ccr_final(s,1)=sum(ccr(s,:),2)/cv.NumTestSets;
        svmstruct=svmtrain(Xtrain,Ytrain);
     for i=1:60
         Ypredict=svmclassify(svmstruct,X_iter);
         X_iter=[X_iter(2:time_size+1) Ypredict];
         Zica2(s,i)=Ypredict;
     end
end

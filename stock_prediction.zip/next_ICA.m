%function [predict_result]=next_ICA(x,y,wd1x,wd1y,ux,uy,time_step,time_predict)
    
size_time=time_step;
window_size=8;
Xtrain=[];
Ytrain=[];

u=ux;
 rep_stock=round(size(wd1x,1)/5);%round(size(u,1)/3);
 
for i=window_size:(size_time-1)
    for n=1:size(u,1)
        if(i>=window_size)
            %xtemp=reshape(u(:,i-window_size+1:i),1,window_size*size(u,1)); %origin
            xtemp=u(n,i-window_size+1:i)';
            Xtrain_temp(n,:)=xtemp; %wd2(:,n)' ];%t_feature(n,:)];% dis_temp(n,i)];                  
            Ytrain_temp(n,1)=u(n,i+1);
        end
    end
    Xtrain=[Xtrain;Xtrain_temp];
    %Xtrain2=[Xtrain2;Xtrain_temp2];
    Ytrain=[Ytrain;Ytrain_temp];
end
% 
% xtmin=min(Xtrain);
% Xtrain=Xtrain-repmat(xtmin,size(Xtrain,1),1);
% xtmax=max(Xtrain);
% Xtrain=Xtrain./repmat(xtmax,size(Xtrain,1),1);
Ytrain(Ytrain>=0)=1;
Ytrain(Ytrain<0)=-1;

Xtest=[];
Ytest=[];

for n=1:size(u,1)
    Xt1(n,:)=u(n,(119-window_size+1):119);%; wd2(:,n)]';%;t_feature(n,:)]';
end
%     Xt1=Xt1-repmat(xtmin,size(Xt1,1),1);
%     Xt1=Xt1./repmat(xtmax,size(Xt1,1),1);

if time_predict>1
    for i=1:time_predict-1
        for n=1:size(x,1)
            xtt=uy(:,i)';
            Xtest_temp(n,:)=[xtt repmat(y(n,i),1,rep_stock)];%mean_temp(n,1) wd2(:,n)' ];%t_feature(n,:)];%dis_tempt(n,i)];
            Ytest_temp(n,1)=y(n,i+1);
        end
        Xtest=[Xtest;Xtest_temp];
        %Xtrain2=[Xtrain2;Xtrain_temp2];   
        Ytest=[Ytest;Ytest_temp];
    end
%     Xtest=Xtest-repmat(xtmin,size(Xtest,1),1);
%     Xtest=Xtest./repmat(xtmax,size(Xtest,1),1);
end


Xtest=[Xt1;Xtest];
Ytest=[uz(:,120);Ytest];

Ytest(Ytest>=0)=1;
Ytest(Ytest<0)=-1;

svmstruct=svmtrain(Xtrain,Ytrain,'kernel_function','linear','boxconstraint',1,'method','SMO','autoscale','true');
y_predict=svmclassify(svmstruct,Xtest);
cm=confusionmat(Ytest,y_predict);
ccr= sum(diag(cm))/sum(sum(cm,1),2);
fprintf('ccr is %d\n',ccr)

%predict_result = reshape(y_predict,size(x,1),time_predict);

%end

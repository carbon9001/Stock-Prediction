
function [Ypredict_hybrid]=hybrid_svmlasso(ICAcomponents,stock_train,pca_mat)
size_time=119;
%x2=x(c==M,:);
window_size=1;
Xtrain=[];
Ytrain=[];
Xtrain2=[];
u=ICAcomponents;
u2=ICAcomponents;
x=stock_train;
wd1=pca_mat;


lambda=0;
fprintf('total number of stock is %d\n',size(wd1,2));
Xtest = u(:,119);
Ypredict_hybrid_temp=zeros(size(wd1,2),60);


for n=1:size(x,1)
    fprintf('stock %d\n',n)
    Xtrain=[];
    Ytrain=[];
for i=1:(size_time-1)
    if(i>=window_size)
        Xtrain_temp(i,:)=reshape(u(:,i-window_size+1:i),1,window_size*size(u,1)); %origin
        %Xtrain_temp(i,:)=reshape(u2(:,i-window_size+1:i),1,window_size*size(u2,1)); %gradieant
        %Xtrain_temp(i,:)=reshape([u(:,i-window_size+1:i);u2(:,i-window_size+1:i)],1,2*window_size*size(u2,1));
        Ytrain_temp(i,1)=x(n,i+1);
    end
end
    Xtrain=[Xtrain;Xtrain_temp];
    %Xtrain2=[Xtrain2;Xtrain_temp2];
    Ytrain=[Ytrain;Ytrain_temp];
    
    Ytrain_svm=Ytrain;
    Ytrain_svm(Ytrain>0)=1;
    Ytrain_svm(Ytrain<=0)=-1;
    
    Xtrain_p=Xtrain(Ytrain>0,:);
    Xtrain_n=Xtrain(Ytrain<=0,:);
    
    Ytrain_p=Ytrain(Ytrain>0,1);
    Ytrain_n=Ytrain(Ytrain<=0,1);
    
    B_p=ridge(Ytrain_p,Xtrain_p,0,0);
    B_n=ridge(Ytrain_n,Xtrain_n,0,0);
    svmstruct=svmtrain(Xtrain,Ytrain_svm,'kernel_function','rbf','boxconstraint',100,'method','SMO','autoscale','false');

    
    svmcollection{n}=svmstruct;
    ridgebp{n}=B_p;
    ridgebn{n}=B_n;
end
fprintf('\n')


%% generate training sets
for t=1:60
    fprintf('done for time step %d\n',t);
%     Xtrain=[];
%     Ytrain=[];
for n=1:size(x,1)
    
%% prediction
Xplus=[1; Xtest];

svm_temp = svmclassify(svmcollection{n},Xtest');
if(svm_temp>0)
    Ypredict_hybrid_temp(n,t)=ridgebp{n}'*Xplus;
else
    Ypredict_hybrid_temp(n,t)=ridgebn{n}'*Xplus;
end

%Ypredict_lasso_temp(:,i) = Xplus * [S.Intercept(S.Index1SE); B(:,S.Index1SE)];
end
Xtest = wd1*Ypredict_hybrid_temp(:,t);
fprintf('\n')
end
Ypredict_hybrid_temp(:,2:60)=0;
Ypredict_hybrid= Ypredict_hybrid_temp;
end
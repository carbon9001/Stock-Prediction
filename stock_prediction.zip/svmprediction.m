

function [Ypredict_svm]=svmprediction(ICAcomponents,stock_train,pca_mat)
size_time=119;
%x2=x(c==M,:);
window_size=1;
Xtrain=[];
Ytrain=[];
Xtrain2=[];

u=ICAcomponents;
u2=ICAcomponents;
x=stock_train;
wd1=pca_mat;

xtemp=x;
xtemp(xtemp<0)=0;
mean_intra_g_p = sum(xtemp,2)./sum(xtemp>0,2);

xtemp=x;
xtemp(xtemp>0)=0;
mean_intra_g_n = sum(xtemp,2)./sum(xtemp<0,2);

mx_p=mean_intra_g_p;
mx_n=mean_intra_g_n;
%% gradiant?
%origin
u2=u;
Xtest = u2(:,119);
Ypredict_svm_temp=zeros(size(x,1),60);
%% generate training samples
for t=1:60
    fprintf('done for time step %d\n',t);
for n=1:size(x,1)
    Xtrain=[];
    Ytrain=[];
for i=1:(size_time-1)
    if(i>=window_size)
        %Xtrain_temp(i,:)=reshape(u(:,i-window_size+1:i),1,window_size*size(u,1)); %origin
        Xtrain_temp(i,:)=reshape(u2(:,i-window_size+1:i),1,window_size*size(u2,1)); %gradieant
        %Xtrain_temp(i,:)=reshape([u(:,i-window_size+1:i);u2(:,i-window_size+1:i)],1,2*window_size*size(u2,1));
        Ytrain_temp(i,1)=x(n,i+1);
    end
end
    Xtrain=[Xtrain;Xtrain_temp];
    %Xtrain2=[Xtrain2;Xtrain_temp2];
    Ytrain=[Ytrain;Ytrain_temp];

Ytrain(Ytrain>0)=1;
Ytrain(Ytrain<=0)=-1;

%fprintf('data generation done\n')    
%fprintf('size x is %d\n',size(x,1))

%% start training

%svmstruct=svmtrain(Xtrain(trin,:),Ytrain(trin,:),'kernel_function','rbf','rbf_sigma',1000,'boxconstraint',1000,'method','SMO','autoscale','false');
svmstruct=svmtrain(Xtrain,Ytrain,'kernel_function','rbf','boxconstraint',100,'method','QP','autoscale','false');



svm_temp = svmclassify(svmstruct,Xtest');
if(svm_temp>0)
    svm_temp = mx_p(n,1);
else
    svm_temp = mx_n(n,1);
end
Ypredict_svm_temp(n,t)=svm_temp;
fprintf('stock %d',n)
end
Xtest = wd1*Ypredict_svm_temp(:,t);
fprintf('\n');

end
Ypredict_svm_temp(:,3:60)=0;
Ypredict_svm = Ypredict_svm_temp;
end

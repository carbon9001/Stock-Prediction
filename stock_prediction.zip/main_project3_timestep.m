clear all
load('train_stock.mat');
%% fill the NaN data in data sets

%we get xtrain_intra (40000*119)
% ytrain_intra(40000*60)
% mean_xintra (40000*1)
% mean_yintra (40000*1)
% numsample = 40000;
% time_step = 119;
% ms : number of "events" extracted: default 10
train_intra=train(:,29:207);
        
numsample=size(train_intra,1); 
time_step=119;
time_predict_all=60;
ms=10;

%seperate data
xtrain_intra = train_intra(:,1:119);
ytrain_intra = train_intra(:,120:179);
%eliminate NaN
%%********************    start of change      ****************************
nan_pos=isnan(train_intra);
train_intra(nan_pos)=0;
means_intra=sum(train_intra,2)/size(train_intra,2);
train_intra=train_intra+nan_pos.*repmat(means_intra,1,size(train_intra,2));

%%************************************************************
xnan_pos=isnan(xtrain_intra);
xtrain_intra(xnan_pos)=0;
ynan_pos=isnan(ytrain_intra);
ytrain_intra(ynan_pos)=0;
%calculate mean
means_xintra=sum(xtrain_intra,2)/size(xtrain_intra,2);
means_yintra=sum(ytrain_intra,2)/size(ytrain_intra,2);
%fill the NaN place
xtrain_intra=xtrain_intra+xnan_pos.*repmat(means_xintra,1,size(xtrain_intra,2));
ytrain_intra=ytrain_intra+ynan_pos.*repmat(means_yintra,1,size(ytrain_intra,2));


%% get gradient of original data
%get train_intra 1:179
xtrain_intra_g=[xtrain_intra zeros(numsample,1)]-[means_xintra xtrain_intra];
xtrain_intra_g=xtrain_intra_g(:,1:119);

ytrain_intra_g=[ytrain_intra zeros(numsample,1)]-[means_yintra ytrain_intra];
ytrain_intra_g=ytrain_intra_g(:,1:60);

%**************************    start of change      ************************************
 train_intra_g=[train_intra zeros(numsample,1)]-[means_intra train_intra];
 train_intra_g=train_intra_g(:,1:179);
 train_intra=train_intra_g;


%********************************************************************************

%% set number of grouping sets, number of stocks per group
%number of grouping sets
ngs=5;                              
%number of stocks per groups
nspg=50;
ms = round(nspg/5);

%% select number of stock samples we need (for testing it could be smaller than total sample number)
%made it a multiple of nspg or index will be floating number
temp_sample = 5000;          
% then we can get the number of groups we need
ng = temp_sample/nspg;

% generate random index
temp_ind=randperm(numsample,temp_sample);
% select the new data sets for xtrain_intra and ytrain_intra
% now size of x y are temp_sample*time_step
xtrain_intra=xtrain_intra_g(temp_ind,1:time_step);
ytrain_intra=ytrain_intra_g(temp_ind,1:time_predict_all);
%**********************    start of change      *************************************
train_intra=train_intra_g(temp_ind,:);
%******************************************************************************

%% generate n gorup of index
% here we get a regroup_matrix=temp_sample*ngs;

% regroup_mat=zeros(temp_sample,ngs);
regroup_mat = grouping(xtrain_intra,20);
%regroup_index = randperm(temp_sample,temp_sample);
% for i=1:ngs
%     current_group=1;
%     start_index=1;
%     end_index=start_index+nspg-1;
%     for j=1:ng
%         regroup_mat(regroup_index(1,start_index:end_index),i)=current_group;
%         start_index=end_index+1;
%         end_index=start_index+nspg-1;
%         current_group=current_group+1;
%     end
% end

fprintf('group index generated\n')
%% train the result matrix
time_predict=1;
stock_predict = zeros(temp_sample,ngs,time_predict);
for i=1:ngs
    for j=1:ng
        %% get the x and y for training
        % now x y is a matrix with nspg(50) columns
        x = xtrain_intra(regroup_mat(:,i)==j,:);
        y = ytrain_intra(regroup_mat(:,i)==j,:);
        %****************    start of change      ***************************
        z = train_intra(regroup_mat(:,i)==j,:);
        icaz = z;
        %**********************************************
        icax = x;
        icay = y;
        
        %% do PCA 
        % get covariance
        % care! no centering here!
        
        %****************     start of change     *********************
        %cov_intra=zeros(nspg,nspg);
        cov_intra = zeros(size(icax,1),size(icax,1));
        for t=1:time_step
            cov_temp=icax(:,i)*icax(:,i)';
            cov_intra=cov_intra+cov_temp;
        end
         
         cov_xintra=cov_intra/time_step;
        
        cov_intra = zeros(size(icay,1),size(icay,1));
        %cov_intra=zeros(nspg,nspg);
        for t=1:time_predict_all
            cov_temp=icay(:,i)*icay(:,i)';
            cov_intra=cov_intra+cov_temp;
        end
        cov_yintra=cov_intra/time_step;

%         cov_intra=zeros(nspg,nspg);
%         for t=1:179
%             cov_temp=icaz(:,i)*icaz(:,i)';
%             cov_intra=cov_intra+cov_temp;
%         end
%         cov_zintra=cov_intra/time_step;
        %************************************
        
        
        %**********        start of change          ***********************
        [Zpca,T,U,mu]=myPCA(cov_xintra,ms);        
        %Zrx = U / T * Zpca + repmat(mu,1,nspg);
        Zrx = U / T * Zpca + repmat(mu,1,size(cov_xintra,1));
        wd1x=U(:,1:ms)';
        
        [Zpca,T,U,mu]=myPCA(cov_yintra,ms);
        Zry = U / T * Zpca + repmat(mu,1,size(cov_yintra,1));
        wd1y=U(:,1:ms)';
        
%         [Zpca,T,U,mu]=myPCA(cov_zintra,ms);
%         Zrz = U / T * Zpca + repmat(mu,1,nspg);
%         wd1z=U(:,1:ms)';
        %*****************************************
        %% do ICA
        %*************************     start of change      ********************************
         [Zica,A,T,mu]=myICA(wd1x*x,ms);
         ux = T \ pinv(A) * Zica + repmat(mu,1,time_step);
        
        [Zica,A,T,mu]=myICA(wd1y*y,ms);
        uy = T \ pinv(A) * Zica + repmat(mu,1,time_predict_all);
        
%         [Zica,A,T,mu]=myICA(wd1z*z,ms);
%         uz = T \ pinv(A) * Zica + repmat(mu,1,179);
        
        %ux=uz(:,1:119);
        %uy=uz(:,120:179);
        %*****************************************************************
        
        %% give the training sets and testing sets, generate results
        % select time steps to predict
        
        %*****************    Start of all ********************************
        %[predict_result]=svm_stock(x,y,wd1x,wd1y,ux,uy,time_step,time_predict);
        [predict_result]=svm_stock(z(:,1:119),z(:,120:179),wd1x,wd1y,ux,uy,time_step,time_predict);
        
        %*********************************************************************
        
        stock_predict(regroup_mat(:,i)==j,i,:)=predict_result;
        
    end
    fprintf('prediction done for group sets id %d\n',i);
end

%% get the true label by counting
stock_predict_final=zeros(temp_sample,time_predict);
for t=1:time_predict
   stock_predict_final(:,t)=mode(stock_predict(:,:,t),2);
end
%% get confusion matrix to see result
% generate proper prediction
true_return=train_intra(:,120:179);
true_return(true_return>=0)=1;
true_return(true_return<0)=-1;
true_return=reshape(true_return(:,1:time_predict),temp_sample*time_predict,1);
stock_predict_final = reshape(stock_predict_final,temp_sample*time_predict,1);
ccr_t = zeros(1,time_predict);
cm_all=zeros(2,2);
for t=1:time_predict
    cm_t=confusionmat(true_return,stock_predict_final);
    cm_all = cm_all+cm_t;
    ccr_t(1,t) = sum(diag(cm_t))/sum(sum(cm_t,1),2);
end
ccr_all = sum(diag(cm_all))/sum(sum(cm_all,1),2);
fprintf('the ccr of all result is %d\n',ccr_all);

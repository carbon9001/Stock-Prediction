function [Ypredict]=predictionFunction(ICAComponent,trainSamples) %ICAComponent = u %trainSample = x

size_time=119;
%x2=x(c==M,:);
window_size=1;
Xtrain=[];
Ytrain=[];
Xtrain2=[];
%% gradiant?
%origin
u2=ICAComponent;
x=trainSamples;
%gradient
 uu=[zeros(size(u,1),1) u];
 uu2=[u zeros(size(u,1),1)];
 u2=uu2-uu;
 u2=u2(:,2:size(u2,2)-1);

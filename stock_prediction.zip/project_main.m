%proprocessing all the data sets

%only line 6 and line  8 has full data

clear all
%replace all the NaN with their average
%cat the data
%id = 1
%features = 2:26
%D-2,D-1=27,28
%ret2-180 = 29:207 
%ret2-120 = 29:147
%ret121-180=148:207
%D+1, D+2 = 208,209
%w_int,w_daily = 210,211

%% load data and preprocessing
load('train_stock.mat')
train_intra=train(:,29:207);
nan_pos=isnan(train_intra);
train_intra(nan_pos)=0;
means_intra=sum(train_intra,2)/size(train_intra,2);
train_intra=train_intra+nan_pos.*repmat(means_intra,1,size(train_intra,2));
feature=train(:,6);
numsample=size(train_intra,1);
time_step=119;

%% no preprocessing
train_intra_g=train_intra;

%% sample gradient
% 
  train_intra_g=[train_intra zeros(numsample,1)]-[means_intra train_intra];
  train_intra_g=train_intra_g(:,1:179);
  train_intra=train_intra_g;

 
% indp=(train_intra>0);
% indn=(train_intra<0);
% mean_intra_g_p = sum(train_intra_g(indp),2)/size(train_intra_g(indp),2);
% mean_intra_g_n = sum(train_intra_g(indn),2)/size(train_intra_g(indn),2);

%% smoothing preprocessing
%train_intra_g=log(train_intra(:,2:119)./train_intra(:,1:118));
%train_intra=train_intra_g;
%train_intra_g=train_intra-repmat((min(train_intra,[],2)-0.1),1,size(train_intra,2));
%train_intra_g=log(train_intra_g);

%train_intra_g=(exp(train_intra)-exp(-1*train_intra))./(exp(train_intra)+exp(-1*train_intra));
%train_intra=train_intra_g;

%% regularization
%train_intra_g=train_intra-repmat(min(train_intra,[],2),1,size(train_intra,2));
%train_intra_g=train_intra_g./repmat(max(train_intra_g,[],2),1,size(train_intra_g,2));

%% window
%  time_windows=3;
%  train_copy=train_intra;
% train_temp=[repmat(means_intra,1,(time_windows-1)/2) train_intra repmat(means_intra,1,(time_windows-1)/2)];
% for w=1:119
%     train_intra(:,w)=sum(train_temp(:,w:w+time_windows),2)/time_windows;
% end

%v=zeros();

%% test data sets
ms=10; %targeet dimesion reduction
%x=train_intra(:,1:119);
temp_sample=50;
temp_ind=randperm(numsample,temp_sample);
x=train_intra(temp_ind,1:time_step);

icax=train_intra_g(temp_ind,1:time_step);

t_feature = feature(temp_ind,:);
% mx_p=mean_intra_g_p(temp_ind,1);
% mx_n=mean_intra_g_n(temp_ind,1);
%x_g=train_intra_g(temp_ind,1:119);
%x=train_intra(:,1:119);

%% cluster
% Z=linkage(icax,'ward','correlation');
% c=cluster(Z,'maxclust',8000);
% M=mode(c);
% temp_ind=(c==M);
% x=x(c==M,:);
% icax=icax(c==M,:);
% t_feature=t_feature(c==M,:);
% ms=round(size(x,1)/4);
% temp_sample=size(x,1);
fprintf('the size of x is %d\n',size(x,1))


% for i=1:40000
%     cr_t=corrcoef(train_intra(1,:),train_intra(i,:));
%     cr(i,1)=cr_t(1,2);
% end
% x=train_intra(cr>0.2,1:119);
% temp_ind=(cr>0.2);
% temp_sample=size(x,1);
%% PCA


%center
% x=train_intra(1:119);
 mean_train=sum(icax,2)/time_step;
% x_cen=x-repmat(mean_train,1,119);
 %cov_intra=zeros(numsample,numsample);
 cov_intra=zeros(temp_sample,temp_sample);
 for i=1:time_step
     %cov_temp=x_cen(:,i)*x_cen(:,i);
     cov_temp=icax(:,i)*icax(:,i)';
     cov_intra=cov_intra+cov_temp;
     sprintf('current time step is %d',i);
 end
 cov_intra=cov_intra/time_step;
 sprintf('covariance done\n')
% cov_intra=cov_intra*cov_intra';
% [V, D]=eig(cov_intra);
% V=V';
% wd1=V(1:ms,:);
% 
% for i=1:119
%     v(:,i)=wd1*x_cen; 
% end
%     v=v+repmat(mean_train,1,119); %v is the 119 converted signals
%     
%[Zpca,T,U,mu]=myPCA(cov_intra,temp_sample);

%we need to ensure that the cov_intra has a dimention larger than ms(number of stock choosing at least ms)
[Zpca,T,U,mu]=myPCA(cov_intra,ms);
Zr = U / T * Zpca + repmat(mu,1,temp_sample);
wd1=U(:,1:ms)';
%% ICA
xt=1:time_step;
xp=120:179;

[Zica,A,T,mu]=myICA(wd1*x,ms); % u is a ms*119 matrix
% for s=1:ms
%      temp_fft=fft(Zica(s,:));
%      temp_fft=[zeros(1,30) temp_fft zeros(1,30)];
%      Zica2(s,:)=abs(ifft(temp_fft));
%     %Zica2(s,:)=repmat(mean(Zica(s,:)),1,60);
%     %Zica2(s,:)=ones(1,60)*max(Zica(s,:));
% end

u = T \ pinv(A) * Zica + repmat(mu,1,time_step);
%denoise u

wd2=x*pinv(u);
wd2=wd2';
%ypredict_intra=regression_lasso(u,x,wd1);
%ypredict_intra = svmprediction(u,x,wd1);
%ypredict_intra = zeros(size(x,1),60);
%ypredict_intra=hybrid_svmlasso(u,x,wd1);
%ypredict_intra=hybrid_svmridge(u,x,wd1);

%Zica=u;
%Zica2 is the predicted result with ICA components(not going to use this)
% for s=1:ms
%     Zica2(s,:)=repmat(mean(u(s,:)),1,60);
% end
% %u2 = T \ pinv(wd1) * Zica2(:,1:60) + repmat(mu,1,60);
% Zica2 = T \ pinv(A) * Zica2(:,1:60) + repmat(mu,1,60);
%u2=pinv(wd1)*u2(:,120:179);
% u2=pinv(wd1)*Zica2;
% for s=1:ms
%     B=ridge(u(s,:)',xt',0,0);
%     ssp(s,:)=B(2,1).*xp+B(1,1);
% end
% Ai=pinv(A);
% %ypredict_intra=zeros(temp_sample,60);
% ypredict_intra=Ai*ssp;
%ypredict_d=zeros(numsample,2);
%ypredict_intra=u2;
%ypredict_intra=pinv(wd1)*pinv(A)*u2;

ypredict_d=zeros(temp_sample,2);

%% JADE ICA
% icam=jadeR(wd1*icax,ms);
% u=icam*wd1*icax;
 ypredict_intra=zeros(size(icax,1),60);



%% regression
%produce ypredict_intra, ypredict_d

%     ypredict_intra=zeros(numsample,60);
%     ypredict_d=zeros(numsample,2);
%     
%     xt=1:119;
%     xp=120:179;
%     ssp=zeros(ms,60);
%     for s=1:ms
%         [B,Stat]=lasso(xt,v(s,:));
%         ssp(s,:)=B(2,1).*xp+B(1,1);
%     end
%     for i=1:60
%         ypredict(:,i)=inv(wd1)*ssp(:,i);
%     end
%% SVM prediction
%     svm_window_size=1;
%     [ypredict_intra,ccr]=updownpredict(Zica,u,svm_window_size);
%     sprintf('prediction done\n');
%% preformance estimate
%ytrain_intra=train(:,148:207);
%ypredict_intra=zeros(size(x,1),60);
%ypredict_d=repmat(sum(train(1:temp_sample,27:28),2)/2,1,2);

ytrain_intra=train_intra(temp_ind,120:179);
%ytrain_d=train(:,208:209);
ytrain_d=train(temp_ind,208:209);
%w_intra=train(:,210);
w_intra=train(temp_ind,210);
%w_d=train(:,211);
w_d=train(temp_ind,211);
wmae=sum((w_intra.*sum(abs(ytrain_intra-ypredict_intra),2)+w_d.*sum(abs(ytrain_d-ypredict_d),2)),1)/size(train,1);
fprintf('estimated wmae is %d\n',wmae);

%% all zero comparison
y_0=zeros(size(x,1),60);
wmae_0=sum((w_intra.*sum(abs(ytrain_intra-y_0),2)+w_d.*sum(abs(ytrain_d-ypredict_d),2)),1)/size(train,1);
fprintf('wmae of all 0 prediction is %d\n',wmae_0);




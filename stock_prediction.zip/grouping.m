%calculate the distance using pdist
%reconstruct a connected graph
%construct a knn graph
%use dijskla
%pick the smallest path, medium path, longest path

function [grouping]=grouping(X,knn)

%X=xtrain_intra;
%knn=5;
nsize = size(X,1);
%knn = knn;%round(nsize/);
ngs=5;
nspg=50;
group_number = nsize/nspg;
subDsize=round(nsize/ngs);


D=pdist(X,'correlation');
fprintf('finished calculate distance, generating graph\n')
size(D)

startind = 1;
G = zeros(nsize,nsize);
for i=1:nsize
    endind = startind+(nsize-i)-1;
    D(1,startind:endind);
    G(i,(i+1):nsize)=D(1,startind:endind);
    G((i+1):nsize,i)=D(1,startind:endind)';
    startind=endind+1;
end

fprintf('finished graph generation, calculating shortest path\n')

knng=zeros(nsize,nsize);
for i=1:nsize
    dis_t=G(i,:);
    sd=sort(G(i,:));
    for k=1:knn
        knng(i,dis_t==sd(1,k))=sd(1,k);
    end
end

D = dijkstra(knng,1:nsize);
D = D.^2;

fprintf('Got shortest path, start grouping\n')

ind=zeros(1,ngs);
for i=1:ngs
    ind(1,i)=(i-1)*subDsize+1;
end

group_result = zeros(nsize,ngs);
gid = ones(1,ngs);

for i=1:nsize
    for j=1:ngs
        if(gid(1,j)<=group_number) 
            if(group_result(i,j)==0)
                sd=sort(D(i,:));
                subD=sd(1,ind(1,j):(ind(1,j)+subDsize-1));
                groupsize_count = 1;
                group_result(i,j)=gid(1,j);
                flg=0;
                for n = 1:subDsize  
                    [~,sid]=find(D(i,:)==subD(1,n));       
                    if(length(sid)==1)
                        if(group_result(sid,j)==0)
                            group_result(sid,j)=gid(1,j);
                            groupsize_count = groupsize_count+1;
                        end
                    else
                        for p=1:length(sid)
                            if(group_result(sid(1,p),j)==0)
                                group_result(sid(1,p),j)=gid(1,j);
                                groupsize_count = groupsize_count+1;
                            end
                        end
                        %fprintf('same distance exists!\n')
                    end
                    if(groupsize_count>=nspg)
                        fprintf('subgroup break\n')
                        flg=1;
                        break;
                    end
                end
                gid(1,j)=gid(1,j)+1;
                if flg==0
                    fprintf('not enough subgroup number,some stock might not contains grouping value\n')
                end
            end         
        end
    end
end
grouping = group_result;
fprintf('finished grouping\n')
    
end

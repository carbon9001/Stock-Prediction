clear all
load('train_stock.mat')
train_c=train(:,29:207);
nan_pos=isnan(train_c);
train_c(nan_pos)=0;
means_intra=sum(train_c,2)/size(train_c,2);
train_c=train_c+nan_pos.*repmat(means_intra,1,size(train_c,2));
train_c=[train_c zeros(size(train_c,1),1)]-[means_intra train_c];
train_c=train_c(:,1:179);
a0=0;
a5=0;
a10=0;
b0=0;
b5=0;
b10=0;
for k=1:5000
for i=1:size(train,1)
    if(i~=k)
        c=corrcoef(train_c(k,:),train_c(i,:));
        cor(1,i)=c(1,2);
    end
end
a=sum(cor>0.5,2);
b=sum(cor>0.4,2);
if(a>=10)
    a10=a10+1;
elseif(a>5)
    a5=a5+1;
elseif(a==0)
    a0=a0+1;
end
if(b>=10)
    b10=b10+1;
elseif(b>5)
    b5=b5+1;
elseif(a==0)
    b0=b0+1;
end
k
end
fprintf('0 correlated 0.5 is %d',a0);
fprintf('5-10 correlated 0.5 is %d',a5);
fprintf('>10 correlated 0.5 is %d',a10);
fprintf('0 correlated 0.4 is %d',b0);
fprintf('5-10 correlated 0.4 is %d',b5);
fprintf('>10 correlated 0.4 is %d',b10);
plot(cor)
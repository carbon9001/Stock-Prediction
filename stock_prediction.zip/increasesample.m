%from the 5000 samples
%do cluster
%around 50 stock per sample sets
%for each sample sets, train svm, with 119 different Ms components sets,
%ylabel can be all the stock return in sample sets
%try to do cross validation to see whether it works

%algorithm
clear Z c M x2 Xtrain Xtrain2 Ytrain Xtrain_temp Ytrain_temp ypredict cm ccr svmstruct ccr_final cv yp_final yp ypredict2
%cluster
  %Z=linkage(x,'single','correlation');
  %c=cluster(Z,'maxclust',50);
%as what I see, no need to do cluster

%M=mode(c);


size_time=119;
%x2=x(c==M,:);
window_size=1;
Xtrain=[];
Ytrain=[];
Xtrain2=[];
%% gradiant?
%origin
u2=u;
%gradient
 uu=[zeros(size(u,1),1) u];
 uu2=[u zeros(size(u,1),1)];
 u2=uu2-uu;
 u2=u2(:,1:size(u2,2)-1);
 
 rep_stock=1;
 
 mean_temp = sum(x,2);
 
 sig_temp = std(x,0,2).^2;
 
 dis_temp = (x-repmat(mean_temp,1,size(x,2))).^2./repmat((2.*sig_temp.*sig_temp),1,size(x,2));
 %dis_temp = abs(x-repmat(mean_temp,1,size(x,2)));

%% SVM

for i=1:(size_time-1)
    for n=1:size(x,1)
        if(i>=window_size)
            %xtemp=reshape(u(:,i-window_size+1:i),1,window_size*size(u,1)); %origin
            xtemp=u(:,i)';
            Xtrain_temp(i,:)=[xtemp repmat(x(n,i),1,rep_stock) dis_temp(n,i)];       
            %Xtrain_temp(i,:)=reshape(u2(:,i-window_size+1:i),1,window_size*size(u2,1)); %gradieant
            %Xtrain_temp(i,:)=reshape([u(:,i-window_size+1:i);u2(:,i-window_size+1:i)],1,2*window_size*size(u2,1));
            Ytrain_temp(i,1)=x(n,i+1);
        end
    end
    Xtrain=[Xtrain;Xtrain_temp];
    %Xtrain2=[Xtrain2;Xtrain_temp2];
    Ytrain=[Ytrain;Ytrain_temp];
end

xtmin=min(Xtrain);
Xtrain=Xtrain-repmat(xtmin,size(Xtrain,1),1);
xtmax=max(Xtrain);
Xtrain=Xtrain./repmat(xtmax,size(Xtrain,1),1);
Ytrain(Ytrain>0)=1;
Ytrain(Ytrain<=0)=-1;

Xtest=[];
Ytest=[];
u_future=wd1*ytrain_intra;
for i=1:60
    for n=1:size(x,1)
        xtt=u_future(:,i)';
        Xtest_temp(i,:)=[xtt ytrain_intra(n,i)];
        Ytest_temp(i,1)=ytrain_intra(n,i+1);
    end
    Xtest=[Xtest;Xtest_temp];
    %Xtrain2=[Xtrain2;Xtrain_temp2];
    Ytest=[Ytest;Ytest_temp];
end
Xtest=Xtest-repmat(xtmin,size(Xtrain,1),1);
Xtest=Xtest./repmat(xtmax,size(Xtrain,1),1);
Ytest(Ytest>0)=1;
Ytest(Ytest<=0)=-1;


%% for doing histogram
% xtmax2=0.7*xtmax;
% xtmin2=0.3*xtmax;
% for p=1:size(Xtrain,2)
%     xtem=Xtrain(:,p);
%     xtem(xtem>xtmax2(1,p),1)=xtmax2(1,p);
%     xtem(xtem<xtmin2(1,p),1)=xtmin2(1,p);
%     Xtrain(:,p)=xtem;
% end
%% continue
%%


%  trin=randperm(size(Ytrain,1),10000);
%  Xtrain=Xtrain(trin,:);
%  Ytrain=Ytrain(trin,:);
fprintf('data generation done\n')    
fprintf('size x is %d\n',size(x,1))
cv=cvpartition(Ytrain,'Kfold',4);
    for i=1:cv.NumTestSets
        trin=cv.training(i);
        tein=cv.test(i);
       %svmstruct=svmtrain(Xtrain(trin,:),Ytrain(trin,:),'kernel_function','rbf','rbf_sigma',1000,'boxconstraint',1000,'method','SMO','autoscale','false');
        svmstruct=svmtrain(Xtrain(trin,:),Ytrain(trin,:),'kernel_function','radial','boxconstraint',1,'method','SMO','autoscale','true');
        ypredict=svmclassify(svmstruct,Xtrain(tein,:));
        %ypredict_t=svmclassify(svmstruct,Xtrain(trin,:)); %for boosting training
        %trin2=xor(Ytrain(trin,:),ypredict_t);%for boosting training
        %svmstruct2=svmtrain(Xtrain(trin2,:),Ytrain(trin2,:),'kernel_function','rbf','boxconstraint',1,'method','SMO','autoscale','false');%for boosting training
        %ypredict=svmclassify(svmstruct2,Xtrain(tein,:));%for boosting training
        %nb=fitNaiveBayes(Xtrain(trin,:),Ytrain(trin,:));
        %ypredict=nb.predict(Xtrain(tein,:));
        %yp_final=zeros(size(yp,1),1);
        cm=confusionmat(Ytrain(tein,:),ypredict);
        ccr(i)=sum(diag(cm))/sum(sum(cm,1),2);
    end
    ccr_final=sum(ccr,2)/cv.NumTestSets;
    
    
    for l=1:size(x,1)
        svmstruct=svmtrain(Xtrain,Ytrain,'kernel_function','radial','boxconstraint',1,'method','SMO','autoscale','true');
        xtest=u(:,119);
        xtest2=[xtest;repmat(x(l,119),rep_stock,1);dis_temp(l,119)]';
%         for p=1:size(Xtrain,2)
%             if xtest2(1,p)>xtmax2(1,p)
%                 xtest2(1,p)=xtmax2(1,p);
%             elseif xtest2(1,p)<xtmin2(1,p)
%                 xtest2(1,p)=xtmin2(1,p);
%             end             
%         end
        xtest2=(xtest2-xtmin)./xtmax;
        yn(l,1)=svmclassify(svmstruct,xtest2);
    end
    yt=ytrain_intra(:,1);
    yt(yt>0)=1;
    yt(yt<=0)=-1;
    cmt=confusionmat(yt,yn);
%

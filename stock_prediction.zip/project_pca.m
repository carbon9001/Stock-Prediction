clear Z c M x2 r Z2 c2 M2 x3 Z3 c3 x4
Z=linkage(x,'ward','correlation');
%Z=linkage(train_copy(1:5000,:));
c=cluster(Z,'maxclust',50);
dendrogram(Z)

M=mode(c);
x2=x(c==M,:);
fprintf('x2 is %d\n',size(x2,1))
% Z2=linkage(x2,'single','correlation');
% c2=cluster(Z2,'maxclust',50);
% M2=mode(c2);
% x3=x2(c2==M,:);
% fprintf('x3 is %d\n',size(x3,1))
% Z3=linkage(x3,'single','correlation');
% c3=cluster(Z3,'maxclust',50);
% x4=x3(c3==M,:);
% fprintf('x4 is %d\n',size(x4,1))
for i=1:40000
    cr_t=corrcoef(train_intra(1,:),train_intra(i,:));
    cr(i)=cr_t(1,2);
end

for i=1:10
    cr_t=corrcoef(Zica(1,:),Zica(i,:));
    cr2(i)=cr_t(1,2);
end

% for i=1:100
%     plot(u(i,:));
%     pause(0.5)
% end
clear Xtrain Ytrain trin tein svmstruct ypredict cm ccr
for n=1:200
for i=1:118
    Xtrain(i,:)=u(:,i);
    Ytrain(i,1)=train_intra(n,i+1);
end
Ytrain(Ytrain>0)=1;
Ytrain(Ytrain<=0)=-1;
cv=cvpartition(Ytrain,'Kfold',4);
    for i=1:cv.NumTestSets
        trin=cv.training(i);
        tein=cv.test(i);
        svmstruct=svmtrain(Xtrain(trin,:),Ytrain(trin,:),'method','QP');
        ypredict=svmclassify(svmstruct,Xtrain(tein,:));
        cm=confusionmat(Ytrain(tein,:),ypredict);
        ccr(n,i)=sum(diag(cm))/sum(sum(cm,1),2);
    end
    ccr_final(n,1)=sum(ccr(n,:),2)/cv.NumTestSets;
end
%from the 5000 samples
%do cluster
%around 50 stock per sample sets
%for each sample sets, train svm, with 119 different Ms components sets,
%ylabel can be all the stock return in sample sets
%try to do cross validation to see whether it works

%algorithm
clear Z c M x2 Xtrain Xtrain2 Ytrain Xtrain_temp Ytrain_temp ypredict cm ccr svmstruct ccr_final cv yp_final yp ypredict2 Xtest Ytest Xtest_temp Ytest_temp 
%cluster
  %Z=linkage(x,'single','correlation');
  %c=cluster(Z,'maxclust',50);
%as what I see, no need to do cluster

%M=mode(c);

size_time=119;
%x2=x(c==M,:);
window_size=1;
Xtrain=[];
Ytrain=[];
Xtrain2=[];
%% gradiant?
%origin
u2=u;
%gradient
 uu=[zeros(size(u,1),1) u];
 uu2=[u zeros(size(u,1),1)];
 u2=uu2-uu;
 u2=u2(:,1:size(u2,2)-1);
 
 
 rep_stock=round(size(wd1,1)/5);%round(size(u,1)/3);
 
 mean_temp = sum(x,2);
 mean_tempt = sum(ytrain_intra,2);
 
 sig_temp = std(x,0,2).^2;%repmat(0.01,size(x,1),1);
 sig_tempt = std(ytrain_intra,0,2).^2;%repmat(0.01,size(ytrain_intra,1),1);
 
 dis_temp = (x-repmat(mean_temp,1,size(x,2))).^2./repmat((2.*sig_temp.*sig_temp),1,size(x,2));
 dis_tempt = (ytrain_intra-repmat(mean_tempt,1,size(ytrain_intra,2))).^2./repmat((2.*sig_tempt.*sig_tempt),1,size(ytrain_intra,2));
 %dis_temp = abs(x-repmat(mean_temp,1,size(x,2)));

%% SVM

for i=1:(size_time-1)
    for n=1:size(x,1)
        if(i>=window_size)
            %xtemp=reshape(u(:,i-window_size+1:i),1,window_size*size(u,1)); %origin
            xtemp=u(:,i)';
            Xtrain_temp(n,:)=[xtemp repmat(x(n,i),1,rep_stock) mean_temp(n,1) dis_temp(n,i)]; %wd2(:,n)' ];%t_feature(n,:)];% dis_temp(n,i)];       
            %Xtrain_temp(i,:)=reshape(u2(:,i-window_size+1:i),1,window_size*size(u2,1)); %gradieant
            %Xtrain_temp(i,:)=reshape([u(:,i-window_size+1:i);u2(:,i-window_size+1:i)],1,2*window_size*size(u2,1));
            Ytrain_temp(n,1)=x(n,i+1);
        end
    end
    Xtrain=[Xtrain;Xtrain_temp];
    %Xtrain2=[Xtrain2;Xtrain_temp2];
    Ytrain=[Ytrain;Ytrain_temp];
end
% 
xtmin=min(Xtrain);
Xtrain=Xtrain-repmat(xtmin,size(Xtrain,1),1);
xtmax=max(Xtrain);
Xtrain=Xtrain./repmat(xtmax,size(Xtrain,1),1);
Ytrain(Ytrain>0)=1;
Ytrain(Ytrain<=0)=-1;

Xtest=[];
Ytest=[];
u_future=wd1*ytrain_intra;
for i=1:59
    for n=1:size(x,1)
        xtt=u_future(:,i)';
        Xtest_temp(n,:)=[xtt repmat(ytrain_intra(n,i),1,rep_stock) mean_temp(n,1) dis_temp(n,i)];%mean_temp(n,1) wd2(:,n)' ];%t_feature(n,:)];%dis_tempt(n,i)];
        Ytest_temp(n,1)=ytrain_intra(n,i+1);
    end
    Xtest=[Xtest;Xtest_temp];
    %Xtrain2=[Xtrain2;Xtrain_temp2];
    Ytest=[Ytest;Ytest_temp];
end


Xtest=Xtest-repmat(xtmin,size(Xtest,1),1);
Xtest=Xtest./repmat(xtmax,size(Xtest,1),1);
Ytest(Ytest>0)=1;
Ytest(Ytest<=0)=-1;


%% for doing histogram
% xtmax2=0.7*xtmax;
% xtmin2=0.3*xtmax;
% for p=1:size(Xtrain,2)
%     xtem=Xtrain(:,p);
%     xtem(xtem>xtmax2(1,p),1)=xtmax2(1,p);
%     xtem(xtem<xtmin2(1,p),1)=xtmin2(1,p);
%     Xtrain(:,p)=xtem;
% end
%% continue
%%


%  trin=randperm(size(Ytrain,1),10000);
%  Xtrain=Xtrain(trin,:);
%  Ytrain=Ytrain(trin,:);
fprintf('data generation done\n')    
fprintf('size x is %d\n',size(x,1))

svmstruct=svmtrain(Xtrain,Ytrain,'kernel_function','linear','rbf_sigma',1,'boxconstraint',0.01,'method','SMO','autoscale','true');
yf=svmclassify(svmstruct,Xtest);
cmf=confusionmat(Ytest,yf);
ccrf=sum(diag(cmf))/sum(sum(cmf,1),2);

Xttt=zeros(size(x,1),size(Xtrain,2));


for n=1:size(x,1)
    Xttt(n,:)=[u(:,119);repmat(x(n,119),rep_stock,1);mean_temp(n,1);dis_temp(n,119)]';%; wd2(:,n)]';%;t_feature(n,:)]';
end
    Xttt=Xttt-repmat(xtmin,size(Xttt,1),1);
    Xttt=Xttt./repmat(xtmax,size(Xttt,1),1);
yttt=svmclassify(svmstruct,Xttt);
yn=ytrain_intra(:,1);
yn(yn>0)=1;
yn(yn<=0)=-1;
cmttt=confusionmat(yn,yttt);

%ccrttt=sum(diag(cmttt))/sum(sum(cmttt,1),2);
for t=1:30

end



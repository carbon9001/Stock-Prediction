corr=zeros(1,size(x,1));
for k=2:size(x,1)
    cor=corrcoef(x(1,:),x(k,:));
    corr(k)=cor(1,2);
end
corrs=sort(corr);
plot(corrs)
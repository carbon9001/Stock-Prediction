
function [Ypredict_lasso]=regression_lasso(ICAcomponents,stock_train,pca_mat)
size_time=119;
%x2=x(c==M,:);
window_size=1;
Xtrain=[];
Ytrain=[];
%Xtrain2=[];
u=ICAcomponents;
u2=ICAcomponents;
x=stock_train;
wd1=pca_mat;


Xtest = u2(:,119);
Ypredict_lasso_temp=zeros(size(wd1,2),60);
%% generate training sets
for t=1:60
    Xtrain=[];
    Ytrain=[];
for n=1:size(x,1)
   
for i=1:(size_time-1)
    if(i>=window_size)
        Xtrain_temp(i,:)=reshape(u(:,i-window_size+1:i),1,window_size*size(u,1)); %origin
        %Xtrain_temp(i,:)=reshape(u2(:,i-window_size+1:i),1,window_size*size(u2,1)); %gradieant
        %Xtrain_temp(i,:)=reshape([u(:,i-window_size+1:i);u2(:,i-window_size+1:i)],1,2*window_size*size(u2,1));
        Ytrain_temp(i,1)=x(n,i+1);
    end
end
    Xtrain=[Xtrain;Xtrain_temp];
    %Xtrain2=[Xtrain2;Xtrain_temp2];
    Ytrain=[Ytrain;Ytrain_temp];

%end

%% train the data
lambda=-3;
%use lasso
[B,S]=lasso(Xtrain,Ytrain,'Lambda',exp(lambda));

%prediction


Xplus=[1; Xtest];
%Ypredict_lasso_temp(:,i) = Xplus * [S.Intercept(S.Index1SE); B(:,S.Index1SE)];
Ypredict_lasso_temp(n,t)=[S.Intercept;B]'*Xplus;

end
Xtest = wd1*Ypredict_lasso_temp(:,t);
%% train data in ridge
Ypredict_lasso= Ypredict_lasso_temp;
end


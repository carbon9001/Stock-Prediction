for i=1:size(x,1)
    cr_t=corrcoef(x(1,:),x(i,:));
    cr(i)=cr_t(1,2);
end
plot(cr(2:i));